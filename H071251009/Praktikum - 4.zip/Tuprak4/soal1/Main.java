// package soal1;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Dekorasi menu = new Dekorasi();

        while (true){
            menu.tampilMenu();
            int pilih = input.nextInt();

            switch (pilih){
                case 1: new Persegi().tampilkan1(); break;
                case 2: new PersegiPanjang().tampilkan2(); break;
                case 3: new BangunDatar().tampilkan3(); break;
                case 4: new Trapesium().tampilkan4(); break;
                case 5: new Kubus().tampilkan5(); break;
                case 6: new Balok().tampilkan6(); break;
                case 7: new Bola().tampilkan7(); break;
                case 8: new Tabung().tampilkan8(); break;
                case 0:
                    System.out.println("Terima kasih!");
                    return;
                default:
                    System.out.println("Pilihan tidak valid!");
            }
        }
    }
}