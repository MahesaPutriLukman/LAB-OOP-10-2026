import java.util.Scanner;

class Persegi {
    double sisi;

    Persegi() {}

    Persegi(double sisi){
        this.sisi = sisi;
    }

    void luas(){
        System.out.println("Luas persegi: " + (sisi * sisi));
    }

    void keliling(){
        System.out.println("Keliling persegi: " + (4 * sisi));
    }

    void tampilkan1(){
        Scanner x = new Scanner(System.in);
        System.out.print("Masukkan sisi: ");
        sisi = x.nextDouble();

        luas();
        keliling();
    }
}

class PersegiPanjang {
    double panjang, lebar;

    PersegiPanjang() {}

    PersegiPanjang(double panjang, double lebar){
        this.panjang = panjang;
        this.lebar = lebar;
    }

    void luas(){
        System.out.println("Luas persegi panjang: " + (panjang * lebar));
    }

    void keliling(){
        System.out.println("Keliling persegi panjang: " + (2 * (panjang + lebar)));
    }

    void tampilkan2(){
        Scanner x = new Scanner(System.in);
        System.out.print("Masukkan panjang: ");
        panjang = x.nextDouble();
        System.out.print("Masukkan lebar: ");
        lebar = x.nextDouble();

        luas();
        keliling();
    }
}

public class BangunDatar {
    double r;

    BangunDatar() {}

    BangunDatar(double r){
        this.r = r;
    }

    void luas(){
        System.out.printf("Luas lingkaran: %.2f\n", Math.PI * r * r);
    }

    void keliling(){
        System.out.printf("Keliling lingkaran: %.2f\n", 2 * Math.PI * r);
    }

    void tampilkan3(){
        Scanner x = new Scanner(System.in);
        System.out.print("Masukkan jari-jari: ");
        r = x.nextDouble();

        luas();
        keliling();
    }
}

class Trapesium {
    double a, b, c, d, t;

    Trapesium() {}

    Trapesium(double a, double b, double c, double d, double t){
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.t = t;
    }

    void luas(){
        System.out.println("Luas trapesium: " + (0.5 * (a + b) * t));
    }

    void keliling(){
        System.out.println("Keliling trapesium: " + (a + b + c + d));
    }

    void tampilkan4(){
        Scanner x = new Scanner(System.in);
        System.out.print("Sisi a: "); a = x.nextDouble();
        System.out.print("Sisi b: "); b = x.nextDouble();
        System.out.print("Sisi c: "); c = x.nextDouble();
        System.out.print("Sisi d: "); d = x.nextDouble();
        System.out.print("Tinggi: "); t = x.nextDouble();

        luas();
        keliling();
    }
}