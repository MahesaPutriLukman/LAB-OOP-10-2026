
import java.util.Scanner;

class Kubus extends Persegi {

    Kubus() {}

    Kubus(double sisi){
        super(sisi);
    }

    void volume(){
        System.out.println("Volume kubus: " + (sisi * sisi * sisi));
    }

    void luasPermukaan(){
        System.out.println("Luas permukaan kubus: " + (6 * sisi * sisi));
    }

    void tampilkan5(){
        Scanner x = new Scanner(System.in);
        System.out.print("Masukkan sisi: ");
        sisi = x.nextDouble();

        volume();
        luasPermukaan();
    }
}

class Balok extends PersegiPanjang {
    double tinggi;

    Balok() {}

    Balok(double p, double l, double t){
        super(p, l);
        this.tinggi = t;
    }

    void volume(){
        System.out.println("Volume balok: " + (panjang * lebar * tinggi));
    }

    void luasPermukaan(){
        System.out.println("Luas permukaan balok: " +
                (2 * (panjang * lebar + panjang * tinggi + lebar * tinggi)));
    }

    void tampilkan6(){
        Scanner x = new Scanner(System.in);
        System.out.print("Panjang: "); panjang = x.nextDouble();
        System.out.print("Lebar: "); lebar = x.nextDouble();
        System.out.print("Tinggi: "); tinggi = x.nextDouble();

        volume();
        luasPermukaan();
    }
}

class Bola extends BangunDatar {

    Bola() {}

    Bola(double r){
        super(r);
    }

    void volume(){
        System.out.printf("Volume bola: %.2f\n", (4.0/3.0) * Math.PI * r * r * r);
    }

    void luasPermukaan(){
        System.out.printf("Luas permukaan bola: %.2f\n", 4 * Math.PI * r * r);
    }

    void tampilkan7(){
        Scanner x = new Scanner(System.in);
        System.out.print("Jari-jari: ");
        r = x.nextDouble();

        volume();
        luasPermukaan();
    }
}

class Tabung extends BangunDatar {
    double tinggi;

    Tabung() {}

    Tabung(double r, double t){
        super(r);
        this.tinggi = t;
    }

    void volume(){
        System.out.printf("Volume tabung: %.2f\n", Math.PI * r * r * tinggi);
    }

    void luasPermukaan(){
        System.out.printf("Luas permukaan tabung: %.2f\n",
                2 * Math.PI * r * (r + tinggi));
    }

    void tampilkan8(){
        Scanner x = new Scanner(System.in);
        System.out.print("Jari-jari: "); r = x.nextDouble();
        System.out.print("Tinggi: "); tinggi = x.nextDouble();

        volume();
        luasPermukaan();
    }
}

class Dekorasi {
    void tampilMenu(){
        System.out.println("\n=== MENU ===");
        System.out.println("1. Persegi");
        System.out.println("2. Persegi Panjang");
        System.out.println("3. Lingkaran");
        System.out.println("4. Trapesium");
        System.out.println("5. Kubus");
        System.out.println("6. Balok");
        System.out.println("7. Bola");
        System.out.println("8. Tabung");
        System.out.println("0. Keluar");
        System.out.print("Pilih: ");
    }
}