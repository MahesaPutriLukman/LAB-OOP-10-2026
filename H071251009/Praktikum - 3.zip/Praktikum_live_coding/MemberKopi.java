package Praktikum_live_coding;
class MemberKopi {
//    1. Atribut Private 
private int poin;
private String password;

// 2. Atribut Protected
protected String namaPelanggan;

// 3. atribut Default
String cabangDaftar;

// 4. Constuktor
public MemberKopi (String namaPelanggan, String password){
    this.namaPelanggan = namaPelanggan;
    this.password = password;
    this.poin = 0;
    this.cabangDaftar = "Kopi Garasi";
}

// 5.Getter
public String getnamaPelanggan(){
    return namaPelanggan;
}

private void log (String pesan){
    System.out.println("[PESAN] : "+ pesan);
}
// 6. Setter dengan validasi 
public void ubahPassword(String passwordLama, String passwordBaru){
    if (this.password.equals(passwordLama)){
        this.password = passwordBaru;
        log("Password berhasil diubah");
    }else {
        log("Gagal!,  Password lama salah");
    }
}

// 7. method tambah poin
public void tambahPoin(int jumlah){
    if (jumlah > 0){
        poin += jumlah;
        log ("Poin bertambah🚀");
    
    }else {
        log ("Jumlah eror");
    }
}

// 8. method tukar kopi 
public void tukarKopi (int hargaPoin, String inputPass){
    if (inputPass.equals(this.password) && (poin>hargaPoin)){
        poin -= hargaPoin;
        log("Kopi berhasil ditukar");
    }else {
        log ("kopi gagal ditukar");
    }
}

}
