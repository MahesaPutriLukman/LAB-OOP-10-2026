package Praktikum_live_coding;

public class Mainp {
    public static void main(String[] args) {
        MemberKopi kopi1 = new MemberKopi("nomas", "1234");
        
        // panggil nama dan cabang 
        System.out.println("Nama Pelanggan : " + kopi1.getnamaPelanggan());
        System.out.println("cabang daftar : " + kopi1.cabangDaftar);

        // ubah pin 
        System.out.println("Ubah pin (Salah)");
        kopi1.ubahPassword("1111", "1104");
        System.out.println("Ubah pin (benar)");
        kopi1.ubahPassword("1234", "1104");

        // tambah poin
        System.out.println("Tambah poin (Salah)");
        kopi1.tambahPoin(-100);
        System.out.println("Tambah poin (Benar)");
        kopi1.tambahPoin(100);

        // tukar kopi 
        System.out.println("Tukar kopi (Salah)");
        kopi1.tukarKopi(50, "1234");
        System.out.println("Tukar kopi (Benar)");
        kopi1.tukarKopi(50, "1104");


        


    }
    
}
