public class MainD {
    public static void main(String[] args) {

        // Instansiasi objek
        DompetDigital dompet = new DompetDigital("12345", "Nopal", "111111");

        // 1. Tampilkan identitas
        System.out.println("ID: " + dompet.getIdNasabah());
        System.out.println("Nama: " + dompet.getNama());
        System.out.println("Saldo: " + dompet.getSaldo());

        System.out.println("\n--- Ubah PIN (Salah) ---");
        dompet.ubahPin("000000", "222222");

        System.out.println("\n--- Ubah PIN (Benar) ---");
        dompet.ubahPin("111111", "222222");

        System.out.println("\n--- Setor Valid ---");
        dompet.setor(5000);

        System.out.println("\n--- Setor Negatif ---");
        dompet.setor(-1000);

        System.out.println("\n--- Tarik PIN Salah ---");
        dompet.tarik(2000, "111111");

        System.out.println("\n--- Tarik PIN Benar ---");
        dompet.tarik(2000, "222222");

        System.out.println("\nSaldo akhir: " + dompet.getSaldo());
    }
}

