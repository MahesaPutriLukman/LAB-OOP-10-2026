class DompetDigital {
    
    // === ATRIBUT ===
    private String idNasabah;   // data aman
    private String pin;         // sangat rahasia
    private double saldo;       // rahasia juga

    protected String nama;      // bisa diwariskan

    int batasMinimal = 1000000;    // default (tanpa modifier)

    // === CONSTRUCTOR ===
    public DompetDigital(String idNasabah, String nama, String pin) {
        this.idNasabah = idNasabah;
        this.nama = nama;
        this.pin = pin;
        this.saldo = 0; // otomatis 0
    }

    // === GETTER (HANYA YANG AMAN) ===
    public String getIdNasabah() {
        return idNasabah;
    }

    public String getNama() {
        return nama;
    }

    public double getSaldo() {
        return saldo;
    }

    //  TIDAK BOLEH getter PIN!

    // === SETTER (UBAH PIN) ===
    public void ubahPin(String pinLama, String pinBaru) {
        if (!this.pin.equals(pinLama)) {
            log("Gagal ubah PIN: PIN lama salah");
            return;
        }

        if (pinBaru.length() != 6) {
            log("Gagal ubah PIN: PIN harus 6 digit");
            return;
        }

        this.pin = pinBaru;
        log("PIN berhasil diubah");
    }

    // === SETOR TUNAI ===
    public void setor(double jumlah) {
        if (jumlah <= 0) {
            log("Setor gagal: nominal tidak valid");
            return;
        }

        saldo += jumlah;
        log("Setor berhasil: +" + jumlah);
    }

    // === TARIK TUNAI ===
    public void tarik(double jumlah, String inputPin) {
        if (!this.pin.equals(inputPin)) {
            log("Tarik gagal: PIN salah");
            return;
        }

        if (jumlah <= 0) {
            log("Tarik gagal: nominal tidak valid");
            return;
        }

        if (saldo < jumlah) {
            log("Tarik gagal: saldo tidak cukup");
            return;
        }

        saldo -= jumlah;
        log("Tarik berhasil: -" + jumlah);
    }

    // === METHOD INTERNAL ===
    private void log(String pesan) {
        System.out.println("[LOG] " + pesan);
    }
}

